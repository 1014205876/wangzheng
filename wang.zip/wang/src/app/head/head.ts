import { Component } from '@angular/core';

@Component({
  selector: 'header',
  templateUrl: './head.html',
  styleUrls: ['./head.css']
})
export class Head {
}
