$(function () {
    let index = 0;
    $('.woffice .banner>.left .absolute>li').hover(function () {
        index=$(this).index()
        $('.woffice .banner>.right>li').removeClass('active');
        $('.woffice .banner>.right>li').eq(index).addClass('active');
    })
})